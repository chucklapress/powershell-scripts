1000,2000,3000 | ForEach-Object -Process {$_/1000}
