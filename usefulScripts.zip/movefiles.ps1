Move-Item \Users\chucklapress\test1.txt -Destination \Users\chucklapress\powershell_scripts\usefulScripts\tst1.txt
